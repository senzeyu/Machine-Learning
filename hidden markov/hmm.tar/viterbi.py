import sys
import numpy as np
tag_dict = {}
word_dict = {}
ind2word = {}
ind2tag = {}
states = []
def read_index2word(index_to_word):
    ind = 0
    with open(index_to_word, 'r') as f:
        for line in f:
            word_dict[line.strip()] = ind
            ind2word[ind] = line.strip()
            ind += 1

def read_index2tag(index_to_tag):
    ind = 0
    with open(index_to_tag, 'r') as f:
        for line in f:
            tag_dict[line.strip()] = ind
            ind2tag[ind] = line.strip()
            states.append(ind)
            ind += 1

def build(hmmprior, hmmemit, hmmtrans):
    prior = np.zeros(len(tag_dict))
    with open(hmmprior, 'r') as f:
        i = 0
        for line in f:
            prior[i] = float(line.strip())
            i += 1

    emit = np.zeros((len(tag_dict),len(word_dict)))
    with open(hmmemit, 'r') as f:
        i = 0
        for line in f:
            j = 0
            for word in line.strip().split():
                emit[i][j] = float(word)
                j += 1
            i += 1

    trans = np.zeros((len(tag_dict), len(tag_dict)))
    with open(hmmtrans, 'r') as f:
        i = 0
        for line in f:
            j = 0
            for word in line.strip().split():
                trans[i][j] = float(word)
                j += 1
            i += 1
    # return prior, emit, trans
    return np.log(prior),np.log(emit),np.log(trans)

def predict(test_input, prior, emit, trans, test_out):
    acc_ct = 0
    total_ct = 0
    out = open(test_out,'w')
    with open (test_input, 'r') as f:
        for line in f:
            sentence = line.strip().split()
            obs = []
            seq = []
            for pair in sentence:
                total_ct += 1
                word, tag = pair.strip().split('_')
                obs.append(word_dict[word])
                seq.append(tag_dict[tag])

            lw,p = viterbi(obs, states, prior, emit, trans)

            T = len(obs)-1
            y = [0] * (T + 1)
            y[T] = int(np.argmax(lw[T]))
            if y[T] == seq[T]:
                acc_ct += 1
            for t in range(1, len(obs)).__reversed__():
                y[t-1] = int(p[t][y[t]])
                if y[t-1] == seq[t-1]:
                    acc_ct += 1
            outline = ''
            for t in range(len(obs)):
                outline += ind2word[obs[t]] + '_' + ind2tag[y[t]] + ' '
            outline = outline[:-1] + '\n'
            out.write(outline)
    return float(acc_ct) / float(total_ct)

# https://en.wikipedia.org/wiki/Viterbi_algorithm
def viterbi(obs, states, prior, emit, trans):
    lw = np.zeros((len(obs), len(states)))
    p = np.zeros((len(obs), len(states)))
    for j in range(len(states)):
        #lw[0][i] = np.log(prior[states[i]]) + np.log(emit[states[i]][obs[0]])
        lw[0][j] = prior[j] + emit[j][obs[0]]
        p[0][j] = j

    for t in range(1, len(obs)):
        for j in range(len(states)):
            #max_trans = lw[t-1][0] + np.log(trans[states[0]][cur_state])
            max_trans = lw[t - 1][0] + trans[0][j]
            argmax_state = 0
            for k in range(1, len(states)):
                tmp_trans = lw[t - 1][k] + trans[k][j]
                if tmp_trans >= max_trans:
                    max_trans = tmp_trans
                    argmax_state = k

            lw[t][j] = max_trans + emit[j][obs[t]]
            p[t][j] = argmax_state

    return lw, p


if __name__ == '__main__':
    test_input = sys.argv[1]
    index_to_word = sys.argv[2]
    index_to_tag = sys.argv[3]
    hmmprior = sys.argv[4]
    hmmemit = sys.argv[5]
    hmmtrans = sys.argv[6]
    predicted_file = sys.argv[7]
    metric_file = sys.argv[8]
    read_index2tag(index_to_tag)
    read_index2word(index_to_word)
    prior, emit, trans = build(hmmprior,hmmemit,hmmtrans)
    metric = predict(test_input,prior, emit, trans, predicted_file)
    with open(metric_file,'w') as f:
        f.write('Accuracy: '+str(metric)+'\n')